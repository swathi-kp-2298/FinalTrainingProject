package com.infinite.ins;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

public class InsDAO {
	SessionFactory sessionFactory;
	
	public int loginCheck(String userName, String passWord) {
		sessionFactory = SessionHelper.getConnection();

		Session session = sessionFactory.openSession(); 
		Criteria cr = session.createCriteria(AgentLogin.class);
		cr.add(Restrictions.eq("userName", userName));
		cr.add(Restrictions.eq("passWord", passWord));
		List<AgentLogin> listUsers = cr.list();
		return listUsers.size();
	}
//	
//	//Customer login
//	public int CustomerloginCheck(String customerId, String customerEmail) {
//		sessionFactory = SessionHelper.getConnection();
//		Session session = sessionFactory.openSession(); 
//		Criteria cr = session.createCriteria(Customer.class);
//		cr.add(Restrictions.eq("customerId", customerId));
//		cr.add(Restrictions.eq("customerEmail", customerEmail));
//		List<Customer> listUsers = cr.list();
//		return listUsers.size();
//	}
	
	
	//Customer login1
		public int Customerlogin(String customerId, String passWord) {
			sessionFactory = SessionHelper.getConnection();
			Session session = sessionFactory.openSession(); 
			Criteria cr = session.createCriteria(Customer.class);
			cr.add(Restrictions.eq("customerId", customerId));
			cr.add(Restrictions.eq("passWord", passWord));
			List<Customer> listUsers = cr.list();
			return listUsers.size();
		}
		
	
//	public String generateLapsedId(){
//		sessionFactory = SessionHelper.getConnection();
//		
//	Session session = sessionFactory.openSession();
//		Criteria cr = session.createCriteria(Lapsed.class);
//		List<Lapsed> Lapsed = cr.list();
//		if(Lapsed.size()==0){
//			return "L001";
//		}
//		int id = Integer.parseInt(Lapsed.get(Lapsed.size()-1).getLapseId().substring(1));
//		String lid = String.format("L%03d", ++id);
//		return lid;
//	}
//
//	public String addLapsed(Lapsed lapsed) {	
//		sessionFactory = SessionHelper.getConnection();
//		Session session = sessionFactory.openSession();
//		String LoanId=generateLapsedId();
//		Transaction t = session.beginTransaction();
//
//		lapsed.setLapseId(LoanId);	
//		session.save(lapsed);
//		t.commit();
//		return "Lapsed Added";
//		}

}
