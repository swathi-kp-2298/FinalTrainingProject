package com.infinite.ins;

public enum Status {
INACTIVE,ACTIVE,LAPSED
}